import React from 'react'
import "./Navbar.css"
import { Link } from 'react-router-dom'

export default function Navbar() {
  return (
    <div>
      <header>
        <div className="navbar">
          <div className="nav-logo border">
            <div className="logo">

            </div>
          </div>

          <div className="nav-address border">
            <p className='add-first'>Deliver to</p>
            <div className='add-icon'>
              <i class="fa-solid fa-location-dot"></i>
              <p className='add-sec'>India</p>
            </div>
          </div>

          <div className="nav-search">
            <select className='search-select'>
              <option value="">All</option>
              <option value="">Clothes</option>
              <option value="">Electronics</option>
              <option value="">Kids</option>
              <option value="">Games</option>
            </select>
            <input type="text" placeholder='Search Amazon' className='search-input' />
            <div className="search-icon"><i class="fa-solid fa-magnifying-glass"></i></div>
          </div>

          <div className="nav-signin border">
            <Link to={"/login"}><span>Hello, sign in</span></Link>
            <p className='nav-second'>Account & Lists</p>
          </div>

          <div className="nav-return border">
            <p><span>Returns</span></p>
            <p className='nav-second'>& Orders</p>
          </div>

          <div className="nav-cart border">
            <Link to={"/cart"} style={{color:"white"}}>
              <i  class="fa-solid fa-cart-shopping"></i>
              Cart
            </Link>
          </div>

        </div>

        <div className="pannel">
          <div className="pannel-all">
            <i class="fa-solid fa-bars"></i>
            <Link to={"/"} style={{color:"white",textDecoration:"none"}}><span>All</span></Link>
          </div>

          <div className="pannel-option">
            <Link to={"/todaysdeal"} className='border' style={{color:"white",textDecoration:"none"}}>Today's Deals</Link>
            <Link to={"/customerservice"} className='border' style={{color:"white",textDecoration:"none",marginLeft:"20px"}}>Customer Service</Link>
            <Link className='border' style={{color:"white",textDecoration:"none",marginLeft:"20px"}}>Registry</Link>
            <Link className='border' style={{color:"white",textDecoration:"none",marginLeft:"20px"}}>Gift Cards</Link>
            <Link to={"/sell"} className='border' style={{color:"white",textDecoration:"none",marginLeft:"20px"}}>Sell</Link>
          </div>

          <div className="pannel-deals border">
            Shop Deals in Electronics
          </div>
        </div>

      </header>
    </div>
  )
}
