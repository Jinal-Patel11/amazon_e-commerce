import React from 'react'
import "./Footer.css"

export default function Footer() {
    return (
        <div>
            <footer>
                <div className="foot-pannel1">
                    Back to Top
                </div>

                <div className='foot-pannel2'>
                <ul>
                    <p>Get to Know Us</p>
                    <a href="##">About Us</a>
                    <a href="##">Careers</a>
                    <a href="##">Blog</a>
                    <a href='##'>Press Releases</a>
                    <a href='##'> Amazon Devices</a>
                    <a href='##'> Amazon Science</a>
                </ul>

                <ul>
                    <p>Connect with Us</p>
                    <a href="##">Facebook</a>
                    <a href="##">Twitter</a>
                    <a href="##">Instagram</a>
                </ul>

                <ul>
                    <p>Make Money With Us</p>
                    <a href="##">Sell on Amazon</a>
                    <a href="##">Sell Under Amazon Acceletor</a>
                    <a href="##">Protect and Build Your Brand</a>
                    <a href='##'>Amazon Global Selling</a>
                    <a href='##'>Became an Affiliate</a>
                    <a href='##'>Fulfilment by Amazon</a>
                    <a href='##'>Advertise Your Product</a>
                    <a href='##'>Amazon Pay on Merchants</a>
                </ul>

                <ul>
                    <p>Let Us Help You</p>
                    <a href="##">Your Acccount</a>
                    <a href="##">Returns center</a>
                    <a href="##">Recalls and Product Safety Alerts</a>
                    <a href='##'>100% Purchase Protection</a>
                    <a href='##'>Amazon App Download</a>
                    <a href='##'>Help</a>
                </ul>
                </div>

                <div className="foot-pannel3">
                        <br />
                    <a href="##">Condition of Use</a>
                    <a href="##">Notice</a>
                    <a href="##">your Ads Privacy Choices</a>
                    <p>© 1996-2024, Amazon.com, Inc. or its affiliates</p>
                </div>

            </footer>
        </div>
    )
}
