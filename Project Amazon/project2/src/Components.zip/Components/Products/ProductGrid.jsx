import React from 'react';
import './ProductGrid.css'; 

const products = {
  keepShoppingFor: [
    { name: "Leriya Fashion Women's...", price: "₹329.00", img: "https://m.media-amazon.com/images/I/815IQLLDWxL._AC_SY190_.jpg" },
    { name: "Selvia Women's Shirt", price: "₹279.00", img: "https://m.media-amazon.com/images/I/51BH6sBkjDL._AC_SY190_.jpg" },
    { name: "Selvia Women's Shirt", price: "₹279.00", img: "https://m.media-amazon.com/images/I/61ytti7Fg0L._AC_SY190_.jpg" },
    { name: "Selvia Women's Shirt", price: "₹279.00", img: "https://m.media-amazon.com/images/I/71LMGs6dccL._AC_SY190_.jpg" },
  ],
  pickUpWhereYouLeftOff: [
    { name: "SEGA Men's White...", price: "₹799.00", img: "https://m.media-amazon.com/images/I/61GCg2ASm5S._AC_SY190_.jpg" },
    { name: "SEGA Men's Navy...", price: "₹680.00", img: "https://m.media-amazon.com/images/I/41MHHy6AxML._AC_SY190_.jpg" },
    { name: "SEGA Men's White...", price: "₹799.00", img: "https://m.media-amazon.com/images/I/61GCg2ASm5S._AC_SY190_.jpg" },
    { name: "SEGA Men's Navy...", price: "₹680.00", img: "https://m.media-amazon.com/images/I/71FLG7SHZBL._AC_SY190_.jpg" },
  ],
  bestsellingProducts: [
    { name: "SKADIOO Weighing Scale", price: "₹266.00", img: "https://m.media-amazon.com/images/I/61WLHUnn+pL._AC_SY190_.jpg" },
    { name: "SKADIOO Weighing Scale", price: "₹266.00", img: "https://m.media-amazon.com/images/I/51Jp1JZdU-L._AC_SY190_.jpg" },
    { name: "SKADIOO Weighing Scale", price: "₹266.00", img: "https://m.media-amazon.com/images/I/61Is7sICRJL._AC_SY190_.jpg" },
    { name: "SKADIOO Weighing Scale", price: "₹266.00", img: "https://m.media-amazon.com/images/I/41vXbOxtvwL._AC_SY190_.jpg" },
  ],
  moreItemsToConsider: [
    { name: "Phool - Mosquito Repellent", price: "₹219.00", img: "https://m.media-amazon.com/images/I/81isGHc8ehL._AC_SY350_.jpg" },
    { name: "Phool - Mosquito Repellent", price: "₹219.00", img: "https://m.media-amazon.com/images/I/81isGHc8ehL._AC_SY350_.jpg" },
    { name: "Phool - Mosquito Repellent", price: "₹219.00", img: "https://m.media-amazon.com/images/I/81isGHc8ehL._AC_SY350_.jpg" },
    { name: "Phool - Mosquito Repellent", price: "₹219.00", img: "https://m.media-amazon.com/images/I/81isGHc8ehL._AC_SY350_.jpg" },
  ]
};

const ProductGrid = () => {
  return (
    <div className="product-grid-container">
      <ProductSection title="Keep shopping for" products={products.keepShoppingFor} />
      <ProductSection title="Pick up where you left off" products={products.pickUpWhereYouLeftOff} />
      <ProductSection title="Up to 70% off | Bestselling products" products={products.bestsellingProducts} />
      <ProductSection title="More items to consider" products={products.moreItemsToConsider} />
    </div>
  );
};

const ProductSection = ({ title, products }) => {
  return (
    <div className="productgrid-section">
      <h3 style={{height:"50px",textAlign:"start"}}>{title}</h3>
      <div className="productgrid-list">
        {products.map((product, index) => (
          <div key={index} className="productgrid-card">
            <img src={product.img} alt={product.name} />
            <p>{product.name}</p>
            <p>{product.price}</p>
          </div>
        ))}
      </div>
      <a href="##" className="see-more" style={{fontSize:"14px"}}>See more</a>
    </div>
  );
};

export default ProductGrid;
