import React, { useState } from 'react';
import './Login.css'; 

const Login = () => {
  const [email, setEmail] = useState('');

  const handleInputChange = (e) => {
    setEmail(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Email:", email);
  };

  return (
    <div className="signin-container">
      <div className="signin-box">
        <img 
          src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" 
          alt="Amazon Logo" 
          className="amazon-logo"
        />
        <h1>Sign-In</h1>
        <form onSubmit={handleSubmit}>
          <label>Email or mobile phone number</label>
          <input 
            type="text" 
            value={email} 
            onChange={handleInputChange} 
            className="signin-input"
          />
          <button type="submit" className="signin-button">
            Continue
          </button>
        </form>
        <a href="##" className="help-link">Need help?</a>
        <hr />
        <div className="new-account-section">
          <p>New to Amazon?</p>
          <button className="create-account-button">
            Create your Amazon account
          </button>
        </div>
      </div>
    </div>
  );
};

export default Login;
